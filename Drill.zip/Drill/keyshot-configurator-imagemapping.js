imagemappingdata =
[
    {
        "image": "Drill Config.162.1.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+65",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.2.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+65",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.3.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+65",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.4.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+65",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.5.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+65",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.6.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+65",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.7.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+65",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.8.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+65",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.9.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+65",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.10.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+65",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.11.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+65",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.12.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+65",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.13.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+65",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.14.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+65",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.15.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+65",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.16.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+65",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.17.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+67",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.18.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+67",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.19.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+67",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.20.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+67",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.21.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+67",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.22.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+67",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.23.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+67",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.24.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+67",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.25.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+67",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.26.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+67",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.27.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+67",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.28.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+67",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.29.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+67",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.30.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+67",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.31.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+67",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.32.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+67",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.33.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+73",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.34.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+73",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.35.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+73",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.36.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+73",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.37.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+73",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.38.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+73",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.39.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+73",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.40.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+73",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.41.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+73",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.42.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+73",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.43.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+73",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.44.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+73",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.45.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+73",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.46.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+73",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.47.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+73",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.48.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+73",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.49.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+290",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.50.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+290",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.51.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+290",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.52.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+290",
            "9+490"
        ]
    },
    {
        "image": "Drill Config.162.53.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+290",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.54.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+290",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.55.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+290",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.56.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+290",
            "9+499"
        ]
    },
    {
        "image": "Drill Config.162.57.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+290",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.58.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+290",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.59.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+290",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.60.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+290",
            "9+509"
        ]
    },
    {
        "image": "Drill Config.162.61.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+565",
            "8+290",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.62.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+567",
            "8+290",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.63.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+570",
            "8+290",
            "9+518"
        ]
    },
    {
        "image": "Drill Config.162.64.jpg",
        "modelsets": [
            1004
        ],
        "multimaterials": [
            "561+574",
            "8+290",
            "9+518"
        ]
    }
];
